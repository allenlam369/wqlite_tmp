package test;

import tidal.CheckTideMissing;

public class TestTime {

	public static void main(String[] args) {
//		CheckTideMissing.genDataGovArchiveUrlToday("base", "key");

	}

}
